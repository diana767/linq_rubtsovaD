﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Security.Cryptography;

namespace DZ_RUBTSOVA
{
    public partial class Form1 : Form
    {
        List<Pp> people = new List<Pp>();
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string file = "file.txt";
            if (!File.Exists(file))
            {
                MessageBox.Show("Файл не найден", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                string[] lines = File.ReadAllLines(file);
                Pp h = new Pp("", "", "", 0, 0);
                foreach (string line in lines)
                {
                    string[] chel = line.Split(' ');
                    string inname = chel[0];
                    h.set_inname(inname);
                    string name = chel[1];
                    h.set_name(name);
                    string otch = chel[2];
                    h.set_otch(otch);
                    int age = Convert.ToInt32(chel[3]);
                    h.set_age(age);
                    double weidth = Convert.ToDouble(chel[4]);
                    h.set_weidth(weidth);
                    string f = $"{h.get_inname()} {h.get_name()} {h.get_otch()} {h.get_age()} {h.get_weidth()}\n\n\n";
                    listBox1.Items.Add(f);
                    people.Add(new Pp(inname, name, otch, age, weidth));
                    var b = from p in people
                            where Convert.ToInt32(p.get_age()) < 40
                            select p;
                    foreach (var a in b)
                    {
                        string f1 = $"ФИО: {a.get_inname()}  {a.get_name()}  {a.get_otch()}  \nВозраст:  {a.get_age()} \n Вес: {a.get_weidth()}\n\n\n";
                        listBox2.Items.Add(f1);
                    }
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            List<Class2> dd = new List<Class2>()
            {
                new Class2 { Name = "Отдел закупок", Strana ="Германия" },
                new Class2 { Name = "Отдел продаж", Strana ="Испания" },
                new Class2 { Name = "Отдел маркетинга", Strana ="Испания" }
            };
            List<Class1> c = new List<Class1>()
            {
                new Class1 {Name="Иванов", dd = "Отдел закупок"},
                new Class1 {Name="Петров", dd ="Отдел закупок"},
                new Class1 {Name="Сидоров", dd = "Отдел продаж "},
                new Class1 {Name="Лямин", dd = "Отдел продаж"},
                new Class1 {Name="Сидоренко", dd = "Отдел маркетинга"},
                new Class1 {Name="Кривоносов", dd = "Отдел продаж"}
            };
            var res = from em in c
                          join d in dd on em.dd equals d.Name
                          select new { Name_ = em.Name, Class1 = em.dd, Region = d.Strana };
            label4.Text += "\n\n";
            foreach (var a in res)
            label4.Text += ($"{a.Name_} - {a.Class1} ({a.Region})\n");           
            var resB = from dep in dd
                          join emp in c on dep.Name equals emp.dd
                          where dep.Strana.StartsWith("И")
                          select emp.Name;
            label3.Text += "\n\n";
            foreach (var b in resB)
             label3.Text += $"{b}\n";
        }
    }
}
